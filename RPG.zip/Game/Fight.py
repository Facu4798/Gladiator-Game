def fight():
    #imports
    from random import uniform,randint
    from Enemy import enemy
    from Character import character
    from Main import menu
    from math import exp
    import methods
    from numpy import absolute
    
    #setting enemy stats
    enemy.strenght = randint(int(character.strenght) - 5, int(character.strenght) + 5)
    enemy.defence = randint(int(character.defence) - 5, int(character.defence) + 5)
    enemy.agility = randint(int(character.agility) - 5, int(character.agility) + 5)
    enemy.health = character.health
    
    #display
    methods.clear()
    print("\nYour stats :")
    print(f"\nStrenght : {character.strenght}")
    print(f"\nDefence : {character.defence}")
    print(f"\nAgility : {character.agility}")
    print("\nEnemy stats : ")
    print(f"\nStrenght : {enemy.strenght}")
    print(f"\nDefence : {enemy.defence}")
    print(f"\nAgility : {enemy.agility}")
    input()
    methods.clear()
    
    while True:
        #battle
        methods.clear()
        print("Health :",character.health,"                                Enemy health :",enemy.health)
        print("\nIt's your turn. What do you choose to do?")
        print("\n--Shield bash")
        print("\n--Attack\n")
        
        #character turn
        fightDecition = input()
        if fightDecition == "shield bash" :
            efficiency = (character.defence - enemy.defence) * 0.1 + 0.2
            if efficiency > uniform(0,1):
                enemy.health -= character.strenght * 1.5
                print(f"Succesful hit! {character.strenght * 1.5} damage dealt")
                input()
            else:
                print("You missed")
                input()
        elif fightDecition == "attack":
            efficiency = (character.strenght - (enemy.defence + enemy.agility) / 2) * 0.1 + 0.5
            if efficiency > uniform(0,1):
                enemy.health -= character.strenght
                print(f"Succesful hit! {character.strenght} damage dealt")
                input()
            else:
                print("You missed")
                input()
        
        #enemy turn
        enemyDecition =uniform(0,1)
        if enemyDecition > 0.5:
            efficiency = (absolute(enemy.defence - character.defence)) * 0.1 + 0.2
            if efficiency > uniform(0,1):
                character.health -= enemy.strenght * 1.5
                print("\nEnemy deals", enemy.strenght * 1.5, "damage")
                input()
            else:
                print("\nEnemy misses shield bash")
                input()
        else:
            efficiency = (absolute(enemy.strenght - (character.defence + character.agility) / 2)) * 0.1 + 0.5
            if efficiency > uniform(0,1):
                character.health -= enemy.strenght
                print("\nEnemy deals", enemy.strenght, "damage")
                input()
            else:
                print("\nEnemy misses attack")
                input()
        #win
        if enemy.health <= 0:
            methods.clear()
            methods.win()
            print("\n--Gold + 100")
            character.gold += 100
            print("\n--EXP  + 100")
            character.exp += 100
            input()
            break;
        #lose
        elif character.health <= 0:
            methods.clear()
            methods.lose()
            print("\n--Gold + 0")
            print("\n--EXP  + 0")
            input()
            break;
        if character.exp >= (100* exp(character.level-1)):
            character.level += 1
            print("\nLevel up:" , character.level)
            input()
            
    menu()
#fight()    
    
    