def exit():
    import pandas as pd
    from Character import character
    from methods import clear
    userfile = pd.read_csv(f"Save Files/{character.user}.csv")
    pers = character.name

    savelist = [character.user,
                character.name,
                character.level,
                character.exp,
                character.gold,
                character.health,
                character.strenght,
                character.defence,
                character.agility,
                character.upgradePoints,
                character.sword,
                character.shield,
                character.boots]
    
    userfile[userfile["Character"]== character.name] = savelist
    userfile.to_csv(f"Save Files/{character.user}.csv",index=False)
    clear()
    quit()