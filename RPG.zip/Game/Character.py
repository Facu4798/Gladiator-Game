#transitory storage for characer data
class character():
    user = " "
    name = " "
    level = 1
    exp = 0
    gold = 0
    health = 100
    strenght = 10
    defence = 10
    agility = 10
    upgradePoints = 0
    sword = 0
    shield = 0
    boots = 0

    