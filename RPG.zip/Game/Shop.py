def shop():
    #imports
    from Character import character
    import sys
    import methods as methods
    import Main
    from math import exp
    

    swordPrice = 150 * exp(character.sword)
    shieldPrice = 200 * exp(character.shield)
    bootPrice = 200 * exp(character.boots) 

    #display
    methods.clear()
    methods.shop()
    print("< Back") 
    print(f"\nWhat would you like to purchase?                               gold:{character.gold}")
    print(f"\n⚔️ ⚔️   Sword:  ${swordPrice}")
    print(f"\n🛡️ 🛡️   Shield: ${shieldPrice}")
    print(f"\n🥾🥾  Boots:  ${bootPrice} \n")
    purchaseDecition = input()

    if purchaseDecition == "back":
        Main.menu()
    elif purchaseDecition == "sword":
        if int(character.gold) >= swordPrice:
            character.gold -= swordPrice
            character.strenght += 10*exp(character.sword)
            character.sword+=1
        else:
            input("Not enough gold")
            shop()
    elif purchaseDecition == "shield":
        if int(character.gold) >= shieldPrice:
            gold -= shieldPrice
            character.defence += 10*exp()
            character.shield += 1
        else:
            input("Not enough gold")
            shop()
    elif purchaseDecition == "boos":
        if int(character.gold) >= bootPrice:
            gold -= bootPrice
            character.agility += 10*exp(character.boots)
            character.boots +=1
        else:
            input("Not enough gold")
            shop()
shop()

    
    
    
    
    
    
    
    
    
    