class enemy:
    strenght = 10
    defence = 10
    agility = 10
    health =100