def upgrade():
    #imports
    from Character import character
    import sys
    import methods
    import Main
    
    #display
    methods.clear()
    methods.upgrade()
    print("< Back\n")
    print(f"What would you like to upgrade?                           upgrade points: {character.upgradePoints}")
    print("\n-- Strenght\n")
    print("-- Defence\n")
    print("-- Agility\n")
    upgradeDecition = input()
    
    #upgrade purchase
    if upgradeDecition == "back":
        Main.menu()
    elif upgradeDecition == "strenght":
        if character.upgradePoints > 0:
            character.strenght +=1
            character.upgradePoints -=1
            upgrade()
        else:
            input("Not enough upgrade points...")
            upgrade()
    elif upgradeDecition == "defence":
        if character.upgradePoints > 0:
            character.defence +=1
            character.upgradePoints -=1
            upgrade()
        else:
            input("Not enough upgrade points...")
            upgrade()
    elif upgradeDecition == "agility":
        if character.upgradePoints > 0:
            character.agility +=1
            character.upgradePoints -=1
            upgrade()
        else:
            input("Not enough upgrade points...")
            upgrade()
#upgrade()



