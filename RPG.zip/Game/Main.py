#imports
import sys
import pandas as pd
from methods import clear,blank,title
from exit import exit
from Character import character
import Shop
import Upgrade
import Fight
import Intro

Intro.intro()    
#main menu defined
def menu():
    clear()
    title()
    print("⚔️ ⚔️  Fight\n")
    print("💲💲 Shop\n")
    print("⇧ ⇧  Upgrade\n")
    print("<--  Quit\n")
    decition= ""
    decition = input()
    if decition == "quit":#exit
        clear()
        exit()
    elif decition == "fight":
        Fight.fight()
    elif decition == "shop":
        Shop.shop()
    elif decition == "upgrade":
        Upgrade.upgrade()
        
#main menu executed
menu()