class user:
    def __init__(self):
        self.ncslist = []
        self.ufile = 0
        self.name = ""
        self.idx = 0




def intro():
    #imports
    import sys
    import pandas as pd
    from shutil import copyfile
    from methods import welcome,clear,blank
    from Character import character

    #asking for username
    clear()
    welcome()
    blank()
    username = input("please enter your username:\n\n")
    character.user = username

    clear()
    try:
        fh = open(f"Save Files/{username}.csv","r")
        #read file if it already exists
        fh.close()
    except:
        copyfile("Save Files/Templates/user_template.csv", f"Save Files/{username}.csv")
    userfile = pd.read_csv(f"Save Files/{username}.csv")
    #no saves
    if len(userfile.index) == 0:
        fileget = input("Enter your new character's name:")
        #get values
        nclist =[username,
                fileget,
                character.level,
                character.exp,
                character.gold,
                character.health,
                character.strenght,
                character.defence,
                character.agility,
                character.upgradePoints,
                character.sword,
                character.shield,
                character.boots]
        #insert values
        userfile.loc[len(userfile.index)] = nclist
        #save values
        userfile.to_csv(f"Save Files/{username}.csv",index=False)
    #with files
    elif len(userfile.index) > 0:
        #print characters
        print("Select character:\n")
        for charac in userfile["Character"]:
            print("--",charac , "\n")
        print("-- New character\n")
        #decition
        fileget = input()
        #new character with saves
        if fileget == "new character":
            fileget = input("Enter your new character's name:")
            #get values
            nclist = [username,
                      fileget,
                      character.level,
                      character.exp,
                      character.gold,
                      character.health,
                      character.strenght,
                      character.defence,
                      character.agility,
                      character.upgradePoints,
                      character.sword,
                      character.shield,
                      character.boots]
            #insert values
            userfile.loc[len(userfile.index)] = nclist
            #save values
            userfile.to_csv(f"Save Files/{username}.csv",index=False)
        #get character index
        ind = userfile.index[userfile['Character'] == fileget].to_list()[0]
        #data assignation
        character.name = userfile.loc[ind,"Character"]
        character.level = userfile.loc[ind,"Level"]
        character.exp = userfile.loc[ind,"EXP"]
        character.gold = userfile.loc[ind,"Gold"]
        character.health = userfile.loc[ind,"Health"]
        character.strenght = userfile.loc[ind,"Strenght"]
        character.defence = userfile.loc[ind,"Defence"]
        character.agility = userfile.loc[ind,"Agility"]
        character.upgradePoints = userfile.loc[ind,"Upgrade Points"]
        character.sword = userfile.loc[ind,"Sword"]
        character.shield = userfile.loc[ind,"Shield"]
        character.boots = userfile.loc[ind,"Boots"]
        
        
            
    
#intro()

