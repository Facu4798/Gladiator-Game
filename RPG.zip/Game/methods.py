#imports
import os
import pandas as pd

#blank line    
def blank () :
        print(" ")

#clear screen command    
clear = lambda: os.system("cls")

#change font size
def changeFontSize(size=2):
    from ctypes import POINTER, WinDLL, Structure, sizeof, byref
    from ctypes.wintypes import BOOL, SHORT, WCHAR, UINT, ULONG, DWORD, HANDLE

    LF_FACESIZE = 32
    STD_OUTPUT_HANDLE = -11

    class COORD(Structure):
        _fields_ = [
            ("X", SHORT),
            ("Y", SHORT),
        ]

    class CONSOLE_FONT_INFOEX(Structure):
        _fields_ = [
            ("cbSize", ULONG),
            ("nFont", DWORD),
            ("dwFontSize", COORD),
            ("FontFamily", UINT),
            ("FontWeight", UINT),
            ("FaceName", WCHAR * LF_FACESIZE)
        ]

    kernel32_dll = WinDLL("kernel32.dll")

    get_last_error_func = kernel32_dll.GetLastError
    get_last_error_func.argtypes = []
    get_last_error_func.restype = DWORD

    get_std_handle_func = kernel32_dll.GetStdHandle
    get_std_handle_func.argtypes = [DWORD]
    get_std_handle_func.restype = HANDLE

    get_current_console_font_ex_func = kernel32_dll.GetCurrentConsoleFontEx
    get_current_console_font_ex_func.argtypes = [HANDLE, BOOL, POINTER(CONSOLE_FONT_INFOEX)]
    get_current_console_font_ex_func.restype = BOOL

    set_current_console_font_ex_func = kernel32_dll.SetCurrentConsoleFontEx
    set_current_console_font_ex_func.argtypes = [HANDLE, BOOL, POINTER(CONSOLE_FONT_INFOEX)]
    set_current_console_font_ex_func.restype = BOOL

    stdout = get_std_handle_func(STD_OUTPUT_HANDLE)
    font = CONSOLE_FONT_INFOEX()
    font.cbSize = sizeof(CONSOLE_FONT_INFOEX)

    font.dwFontSize.X = size
    font.dwFontSize.Y = size

    set_current_console_font_ex_func(stdout, False, byref(font))
 
#the title in big letters    
def title():
    print("   ____   _               _   _           _                  ")
    print("  / ___| | |   __ _    __| | (_)   __ _  | |_    ___    _ __ ")
    print(" | |  _  | |  / _` |  / _` | | |  / _` | | __|  / _ \  | '__|")
    print(" | |_| | | | | (_| | | (_| | | | | (_| | | |_  | (_) | | |   ")
    print("  \____| |_|  \__,_|  \__,_| |_|  \__,_|  \__|  \___/  |_| \n")    
def welcome():
    print(" __    __        _                                 _            _    _                                             ")
    print("/ / /\ \ \  ___ | |  ___   ___   _ __ ___    ___  | |_   ___   | |_ | |__    ___    __ _  _ __   ___  _ __    __ _ ")
    print("\ \/  \/ / / _ \| | / __| / _ \ | '_ ` _ \  / _ \ | __| / _ \  | __|| '_ \  / _ \  / _` || '__| / _ \| '_ \  / _` |")
    print(" \  /\  / |  __/| || (__ | (_) || | | | | ||  __/ | |_ | (_) | | |_ | | | ||  __/ | (_| || |   |  __/| | | || (_| |")
    print("  \/  \/   \___||_| \___| \___/ |_| |_| |_| \___|  \__| \___/   \__||_| |_| \___|  \__,_||_|    \___||_| |_| \__,_|")
def shop():
    print(" ____                            ")                     
    print("/ ___|   _                       ")
    print("| (__   | |__     ___    ____    ") 
    print("\___ \  | '_ \   / _ \  | '_ \   ")
    print(" ___) | | | | | | (_) | | |_) |  ")
    print("|____/  |_| |_|  \___/  | .__/   ")
    print("                        |_|    \n")
def upgrade():
    print(" _   _                                      _         ")
    print("| | | |  _ __     __ _   _ __    __ _    __| |   ___  ") 
    print("| | | | | '_ \   / _` | | '__|  / _` |  / _` |  / _ \ ")
    print("| |_| | | |_) | | (_| | | |    | (_| | | (_| | |  __/ ")
    print(" \___/  | .__/   \__, | |_|     \__,_|  \__,_|  \___| ")
    print("        |_|      |___/                              \n")
def win():
    print("__   __                               _           _   ")
    print("\ \ / /   ___    _   _    __      __ (_)  _ __   | |  ")
    print(" \ V /   / _ \  | | | |   \ \ /\ / / | | | '_ \  | |  ")
    print("  | |   | (_) | | |_| |    \ V  V /  | | | | | | |_|  ")
    print("  |_|    \___/   \__,_|     \_/\_/   |_| |_| |_| (_)\n")
def lose():
    print(" __   __                    _                 _     ")
    print(" \ \ / /   ___    _   _    | |   ___    ___  | |_   ")
    print("  \ V /   / _ \  | | | |   | |  / _ \  / __| | __|  ")
    print("   | |   | (_) | | |_| |   | | | (_) | \__ \ | |_   ")
    print("   |_|    \___/   \__,_|   |_|  \___/  |___/  \__|\n")
                                                  


